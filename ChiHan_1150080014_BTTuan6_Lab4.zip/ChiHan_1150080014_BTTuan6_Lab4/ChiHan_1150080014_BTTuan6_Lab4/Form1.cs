﻿using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Npgsql;

namespace ChiHan_1150080014_BTTuan6_Lab4
{
    public partial class Form1 : Form
    {
        private readonly string connString =
            "Host=localhost;Port=5432;Database=PPPTPMHDT_Lab4;Username=postgres;Password=Chihan0403@";

        private NpgsqlConnection pgCon;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpenConn_Click(object sender, EventArgs e)
        {
            try
            {
                if (pgCon == null) pgCon = new NpgsqlConnection(connString);
                if (pgCon.State == ConnectionState.Closed) pgCon.Open();
                MessageBox.Show("Kết nối PostgreSQL thành công!");
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString(), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnCloseConn_Click(object sender, EventArgs e)
        {
            try
            {
                if (pgCon != null && pgCon.State != ConnectionState.Closed)
                {
                    pgCon.Close();
                    MessageBox.Show("Đã đóng kết nối.");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void btnCountSV_Click(object sender, EventArgs e)
        {
            EnsureOpen();
            using (var cmd = new NpgsqlCommand("SELECT COUNT(*) FROM sinhvien;", pgCon))
            {
                long count = (long)cmd.ExecuteScalar();
                MessageBox.Show($"Số lượng sinh viên: {count}");
            }
        }

        private void btnGetOne_Click(object sender, EventArgs e)
        {
            EnsureOpen();
            string maSV = txtMaSV.Text.Trim();
            if (string.IsNullOrEmpty(maSV))
            {
                MessageBox.Show("Nhập Mã SV trước.");
                txtMaSV.Focus();
                return;
            }

            using (var cmd = new NpgsqlCommand(
                @"SELECT masv, tensv, gioitinh, ngaysinh, quequan, malop
                  FROM sinhvien WHERE masv = @masv;", pgCon))
            {
                cmd.Parameters.AddWithValue("@masv", maSV);

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtTenSV.Text = reader.IsDBNull(1) ? "" : reader.GetString(1);
                        txtGioiTinh.Text = reader.IsDBNull(2) ? "" : reader.GetString(2);
                        txtNgaySinh.Text = reader.IsDBNull(3) ? "" : reader.GetDateTime(3).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                        txtQueQuan.Text = reader.IsDBNull(4) ? "" : reader.GetString(4);
                        txtMaLop.Text = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy sinh viên.");
                    }
                }
            }
        }

        private void btnLoadAll_Click(object sender, EventArgs e)
        {
            EnsureOpen();
            using (var da = new NpgsqlDataAdapter(
                @"SELECT masv AS ""Mã SV"",
                         tensv AS ""Tên SV"",
                         gioitinh AS ""Giới tính"",
                         ngaysinh AS ""Ngày sinh"",
                         quequan AS ""Quê quán"",
                         malop   AS ""Mã lớp""
                  FROM sinhvien
                  ORDER BY masv;", pgCon))
            {
                var dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                if (dgv.Columns.Contains("Ngày sinh"))
                    dgv.Columns["Ngày sinh"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }
        }

        private void btnLopTheoKhoa_Click(object sender, EventArgs e)
        {
            EnsureOpen();
            string maKhoa = txtMaKhoa.Text.Trim();
            lvLop.Items.Clear();

            using (var cmd = new NpgsqlCommand(
                @"SELECT tenlop, malop FROM lop WHERE makhoa = @makhoa ORDER BY tenlop;", pgCon))
            {
                cmd.Parameters.AddWithValue("@makhoa", maKhoa);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var lvi = new ListViewItem(reader.GetString(0));
                        lvi.SubItems.Add(reader.GetString(1));
                        lvLop.Items.Add(lvi);
                    }
                }
            }
        }

        private void btnSVTheoLop_Click(object sender, EventArgs e)
        {
            EnsureOpen();
            string maLop = txtMaLopFilter.Text.Trim();

            using (var da = new NpgsqlDataAdapter(
                @"SELECT masv AS ""Mã SV"",
                         tensv AS ""Tên SV"",
                         gioitinh AS ""Giới tính"",
                         ngaysinh AS ""Ngày sinh"",
                         quequan AS ""Quê quán"",
                         malop   AS ""Mã lớp""
                  FROM sinhvien
                  WHERE malop = @malop
                  ORDER BY tensv;", pgCon))
            {
                da.SelectCommand.Parameters.AddWithValue("@malop", maLop);
                var dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                if (dgv.Columns.Contains("Ngày sinh"))
                    dgv.Columns["Ngày sinh"].DefaultCellStyle.Format = "dd/MM/yyyy";
            }
        }

        private void EnsureOpen()
        {
            if (pgCon == null) pgCon = new NpgsqlConnection(connString);
            if (pgCon.State == ConnectionState.Closed) pgCon.Open();
        }
    }
}
