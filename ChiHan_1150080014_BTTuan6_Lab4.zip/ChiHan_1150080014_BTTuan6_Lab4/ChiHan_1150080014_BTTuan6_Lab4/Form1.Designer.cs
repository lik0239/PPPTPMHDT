﻿namespace ChiHan_1150080014_BTTuan6_Lab4
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;

        private System.Windows.Forms.GroupBox grpConn;
        private System.Windows.Forms.Button btnOpenConn;
        private System.Windows.Forms.Button btnCloseConn;

        private System.Windows.Forms.GroupBox grpOne;
        private System.Windows.Forms.Label lblMaSV;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.Button btnGetOne;
        private System.Windows.Forms.Button btnCountSV;
        private System.Windows.Forms.Label lblTenSV;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.TextBox txtGioiTinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.TextBox txtNgaySinh;
        private System.Windows.Forms.Label lblQueQuan;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.Label lblMaLop;
        private System.Windows.Forms.TextBox txtMaLop;

        private System.Windows.Forms.GroupBox grpParam;
        private System.Windows.Forms.Label lblMaKhoa;
        private System.Windows.Forms.TextBox txtMaKhoa;
        private System.Windows.Forms.Button btnLopTheoKhoa;
        private System.Windows.Forms.ListView lvLop;
        private System.Windows.Forms.ColumnHeader colTenLop;
        private System.Windows.Forms.ColumnHeader colMaLop2;
        private System.Windows.Forms.Label lblMaLopFilter;
        private System.Windows.Forms.TextBox txtMaLopFilter;
        private System.Windows.Forms.Button btnSVTheoLop;

        private System.Windows.Forms.GroupBox grpList;
        private System.Windows.Forms.Button btnLoadAll;
        private System.Windows.Forms.DataGridView dgv;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.lblTitle = new System.Windows.Forms.Label();
            this.grpConn = new System.Windows.Forms.GroupBox();
            this.btnOpenConn = new System.Windows.Forms.Button();
            this.btnCloseConn = new System.Windows.Forms.Button();

            this.grpOne = new System.Windows.Forms.GroupBox();
            this.lblMaSV = new System.Windows.Forms.Label();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.btnGetOne = new System.Windows.Forms.Button();
            this.btnCountSV = new System.Windows.Forms.Button();
            this.lblTenSV = new System.Windows.Forms.Label();
            this.txtTenSV = new System.Windows.Forms.TextBox();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.txtGioiTinh = new System.Windows.Forms.TextBox();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtNgaySinh = new System.Windows.Forms.TextBox();
            this.lblQueQuan = new System.Windows.Forms.Label();
            this.txtQueQuan = new System.Windows.Forms.TextBox();
            this.lblMaLop = new System.Windows.Forms.Label();
            this.txtMaLop = new System.Windows.Forms.TextBox();

            this.grpParam = new System.Windows.Forms.GroupBox();
            this.lblMaKhoa = new System.Windows.Forms.Label();
            this.txtMaKhoa = new System.Windows.Forms.TextBox();
            this.btnLopTheoKhoa = new System.Windows.Forms.Button();
            this.lvLop = new System.Windows.Forms.ListView();
            this.colTenLop = new System.Windows.Forms.ColumnHeader();
            this.colMaLop2 = new System.Windows.Forms.ColumnHeader();
            this.lblMaLopFilter = new System.Windows.Forms.Label();
            this.txtMaLopFilter = new System.Windows.Forms.TextBox();
            this.btnSVTheoLop = new System.Windows.Forms.Button();

            this.grpList = new System.Windows.Forms.GroupBox();
            this.btnLoadAll = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 680);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LAB 4 - PostgreSQL (Npgsql)";

            this.lblTitle.Text = "WINFORMS + POSTGRESQL (LAB 4)";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblTitle.AutoSize = false;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Location = new System.Drawing.Point(10, 10);
            this.lblTitle.Size = new System.Drawing.Size(960, 40);
            this.Controls.Add(this.lblTitle);

            this.grpConn.Text = "Kết nối CSDL";
            this.grpConn.Location = new System.Drawing.Point(20, 60);
            this.grpConn.Size = new System.Drawing.Size(940, 70);
            this.Controls.Add(this.grpConn);

            this.btnOpenConn.Text = "Mở kết nối";
            this.btnOpenConn.Location = new System.Drawing.Point(20, 25);
            this.btnOpenConn.Size = new System.Drawing.Size(120, 32);
            this.btnOpenConn.Click += new System.EventHandler(this.btnOpenConn_Click);
            this.grpConn.Controls.Add(this.btnOpenConn);

            this.btnCloseConn.Text = "Đóng kết nối";
            this.btnCloseConn.Location = new System.Drawing.Point(160, 25);
            this.btnCloseConn.Size = new System.Drawing.Size(120, 32);
            this.btnCloseConn.Click += new System.EventHandler(this.btnCloseConn_Click);
            this.grpConn.Controls.Add(this.btnCloseConn);

            this.grpOne.Text = "Sinh viên (1 dòng - ExecuteReader)";
            this.grpOne.Location = new System.Drawing.Point(20, 135);
            this.grpOne.Size = new System.Drawing.Size(940, 150);
            this.Controls.Add(this.grpOne);

            this.lblMaSV.Text = "Mã SV:";
            this.lblMaSV.Location = new System.Drawing.Point(16, 30);
            this.lblMaSV.AutoSize = true;
            this.grpOne.Controls.Add(this.lblMaSV);

            this.txtMaSV.Location = new System.Drawing.Point(70, 26);
            this.txtMaSV.Size = new System.Drawing.Size(150, 22);
            this.grpOne.Controls.Add(this.txtMaSV);

            this.btnGetOne.Text = "Xem thông tin";
            this.btnGetOne.Location = new System.Drawing.Point(230, 24);
            this.btnGetOne.Size = new System.Drawing.Size(120, 26);
            this.btnGetOne.Click += new System.EventHandler(this.btnGetOne_Click);
            this.grpOne.Controls.Add(this.btnGetOne);

            this.btnCountSV.Text = "Đếm SV (ExecuteScalar)";
            this.btnCountSV.Location = new System.Drawing.Point(360, 24);
            this.btnCountSV.Size = new System.Drawing.Size(170, 26);
            this.btnCountSV.Click += new System.EventHandler(this.btnCountSV_Click);
            this.grpOne.Controls.Add(this.btnCountSV);

            this.lblTenSV.Text = "Tên SV:";
            this.lblTenSV.Location = new System.Drawing.Point(16, 65);
            this.lblTenSV.AutoSize = true;
            this.grpOne.Controls.Add(this.lblTenSV);

            this.txtTenSV.Location = new System.Drawing.Point(86, 62);
            this.txtTenSV.Size = new System.Drawing.Size(220, 22);
            this.txtTenSV.ReadOnly = true;
            this.grpOne.Controls.Add(this.txtTenSV);

            this.lblGioiTinh.Text = "Giới tính:";
            this.lblGioiTinh.Location = new System.Drawing.Point(366, 65);
            this.lblGioiTinh.AutoSize = true;
            this.grpOne.Controls.Add(this.lblGioiTinh);

            this.txtGioiTinh.Location = new System.Drawing.Point(436, 62);
            this.txtGioiTinh.Size = new System.Drawing.Size(120, 22);
            this.txtGioiTinh.ReadOnly = true;
            this.grpOne.Controls.Add(this.txtGioiTinh);

            this.lblNgaySinh.Text = "Ngày sinh:";
            this.lblNgaySinh.Location = new System.Drawing.Point(16, 100);
            this.lblNgaySinh.AutoSize = true;
            this.grpOne.Controls.Add(this.lblNgaySinh);

            this.txtNgaySinh.Location = new System.Drawing.Point(86, 97);
            this.txtNgaySinh.Size = new System.Drawing.Size(150, 22);
            this.txtNgaySinh.ReadOnly = true;
            this.grpOne.Controls.Add(this.txtNgaySinh);

            this.lblQueQuan.Text = "Quê quán:";
            this.lblQueQuan.Location = new System.Drawing.Point(366, 100);
            this.lblQueQuan.AutoSize = true;
            this.grpOne.Controls.Add(this.lblQueQuan);

            this.txtQueQuan.Location = new System.Drawing.Point(446, 97);
            this.txtQueQuan.Size = new System.Drawing.Size(200, 22);
            this.txtQueQuan.ReadOnly = true;
            this.grpOne.Controls.Add(this.txtQueQuan);

            this.lblMaLop.Text = "Mã lớp:";
            this.lblMaLop.Location = new System.Drawing.Point(740, 65);
            this.lblMaLop.AutoSize = true;
            this.grpOne.Controls.Add(this.lblMaLop);

            this.txtMaLop.Location = new System.Drawing.Point(790, 62);
            this.txtMaLop.Size = new System.Drawing.Size(120, 22);
            this.txtMaLop.ReadOnly = true;
            this.grpOne.Controls.Add(this.txtMaLop);

            this.grpParam.Text = "Truy vấn có tham số";
            this.grpParam.Location = new System.Drawing.Point(20, 290);
            this.grpParam.Size = new System.Drawing.Size(940, 150);
            this.Controls.Add(this.grpParam);

            this.lblMaKhoa.Text = "Mã khoa:";
            this.lblMaKhoa.Location = new System.Drawing.Point(16, 30);
            this.lblMaKhoa.AutoSize = true;
            this.grpParam.Controls.Add(this.lblMaKhoa);

            this.txtMaKhoa.Location = new System.Drawing.Point(80, 26);
            this.txtMaKhoa.Size = new System.Drawing.Size(120, 22);
            this.grpParam.Controls.Add(this.txtMaKhoa);

            this.btnLopTheoKhoa.Text = "Lớp theo khoa";
            this.btnLopTheoKhoa.Location = new System.Drawing.Point(210, 24);
            this.btnLopTheoKhoa.Size = new System.Drawing.Size(120, 26);
            this.btnLopTheoKhoa.Click += new System.EventHandler(this.btnLopTheoKhoa_Click);
            this.grpParam.Controls.Add(this.btnLopTheoKhoa);

            this.lvLop.Location = new System.Drawing.Point(16, 60);
            this.lvLop.Size = new System.Drawing.Size(420, 80);
            this.lvLop.View = System.Windows.Forms.View.Details;
            this.lvLop.FullRowSelect = true;
            this.lvLop.GridLines = true;
            this.colTenLop.Text = "Tên lớp"; this.colTenLop.Width = 260;
            this.colMaLop2.Text = "Mã lớp"; this.colMaLop2.Width = 140;
            this.lvLop.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colTenLop, this.colMaLop2 });
            this.grpParam.Controls.Add(this.lvLop);

            this.lblMaLopFilter.Text = "Mã lớp:";
            this.lblMaLopFilter.Location = new System.Drawing.Point(470, 30);
            this.lblMaLopFilter.AutoSize = true;
            this.grpParam.Controls.Add(this.lblMaLopFilter);

            this.txtMaLopFilter.Location = new System.Drawing.Point(520, 26);
            this.txtMaLopFilter.Size = new System.Drawing.Size(120, 22);
            this.grpParam.Controls.Add(this.txtMaLopFilter);

            this.btnSVTheoLop.Text = "SV theo lớp";
            this.btnSVTheoLop.Location = new System.Drawing.Point(650, 24);
            this.btnSVTheoLop.Size = new System.Drawing.Size(120, 26);
            this.btnSVTheoLop.Click += new System.EventHandler(this.btnSVTheoLop_Click);
            this.grpParam.Controls.Add(this.btnSVTheoLop);

            this.grpList.Text = "Danh sách sinh viên (nhiều dòng)";
            this.grpList.Location = new System.Drawing.Point(20, 445);
            this.grpList.Size = new System.Drawing.Size(940, 210);
            this.Controls.Add(this.grpList);

            this.btnLoadAll.Text = "Tải tất cả SV";
            this.btnLoadAll.Location = new System.Drawing.Point(16, 24);
            this.btnLoadAll.Size = new System.Drawing.Size(120, 26);
            this.btnLoadAll.Click += new System.EventHandler(this.btnLoadAll_Click);
            this.grpList.Controls.Add(this.btnLoadAll);

            this.dgv.Location = new System.Drawing.Point(16, 56);
            this.dgv.Size = new System.Drawing.Size(910, 140);
            this.dgv.AllowUserToAddRows = false;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.grpList.Controls.Add(this.dgv);

            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion
    }
}
