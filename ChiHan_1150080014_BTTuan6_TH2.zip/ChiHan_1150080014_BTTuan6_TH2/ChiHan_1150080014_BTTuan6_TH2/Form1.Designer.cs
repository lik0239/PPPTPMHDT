﻿namespace ChiHan_1150080014_BTTuan6_TH2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;

        private System.Windows.Forms.GroupBox grpInfo;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.Label lblLop;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.TextBox txtLop;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtDiaChi;

        private System.Windows.Forms.GroupBox grpActions;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThoat;

        private System.Windows.Forms.GroupBox grpList;
        private System.Windows.Forms.ListView lvSinhVien;
        private System.Windows.Forms.ColumnHeader colHoTen;
        private System.Windows.Forms.ColumnHeader colNgaySinh;
        private System.Windows.Forms.ColumnHeader colLop;
        private System.Windows.Forms.ColumnHeader colDiaChi;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.lblTitle = new System.Windows.Forms.Label();

            this.grpInfo = new System.Windows.Forms.GroupBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.lblLop = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.txtLop = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.txtDiaChi = new System.Windows.Forms.TextBox();

            this.grpActions = new System.Windows.Forms.GroupBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();

            this.grpList = new System.Windows.Forms.GroupBox();
            this.lvSinhVien = new System.Windows.Forms.ListView();
            this.colHoTen = new System.Windows.Forms.ColumnHeader();
            this.colNgaySinh = new System.Windows.Forms.ColumnHeader();
            this.colLop = new System.Windows.Forms.ColumnHeader();
            this.colDiaChi = new System.Windows.Forms.ColumnHeader();

            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 580);
            this.Text = "Danh sách sinh viên";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            this.lblTitle.Text = "DANH MỤC SINH VIÊN";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblTitle.AutoSize = false;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Location = new System.Drawing.Point(10, 10);
            this.lblTitle.Size = new System.Drawing.Size(880, 48);
            this.Controls.Add(this.lblTitle);

            this.grpInfo.Text = "Thông tin sinh viên:";
            this.grpInfo.Location = new System.Drawing.Point(20, 65);
            this.grpInfo.Size = new System.Drawing.Size(860, 120);
            this.Controls.Add(this.grpInfo);

            this.lblHoTen.Text = "Họ tên:";
            this.lblHoTen.Location = new System.Drawing.Point(16, 30);
            this.lblHoTen.AutoSize = true;
            this.grpInfo.Controls.Add(this.lblHoTen);

            this.txtHoTen.Location = new System.Drawing.Point(70, 26);
            this.txtHoTen.Size = new System.Drawing.Size(260, 22);
            this.grpInfo.Controls.Add(this.txtHoTen);

            this.lblLop.Text = "Lớp:";
            this.lblLop.Location = new System.Drawing.Point(360, 30);
            this.lblLop.AutoSize = true;
            this.grpInfo.Controls.Add(this.lblLop);

            this.txtLop.Location = new System.Drawing.Point(405, 26);
            this.txtLop.Size = new System.Drawing.Size(180, 22);
            this.grpInfo.Controls.Add(this.txtLop);

            this.lblNgaySinh.Text = "Ngày sinh:";
            this.lblNgaySinh.Location = new System.Drawing.Point(16, 70);
            this.lblNgaySinh.AutoSize = true;
            this.grpInfo.Controls.Add(this.lblNgaySinh);

            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(90, 66);
            this.dtpNgaySinh.Size = new System.Drawing.Size(150, 22);
            this.grpInfo.Controls.Add(this.dtpNgaySinh);

            this.lblDiaChi.Text = "Địa chỉ:";
            this.lblDiaChi.Location = new System.Drawing.Point(360, 70);
            this.lblDiaChi.AutoSize = true;
            this.grpInfo.Controls.Add(this.lblDiaChi);

            this.txtDiaChi.Location = new System.Drawing.Point(405, 66);
            this.txtDiaChi.Size = new System.Drawing.Size(430, 22);
            this.grpInfo.Controls.Add(this.txtDiaChi);

            this.grpActions.Text = "Chức năng:";
            this.grpActions.Location = new System.Drawing.Point(20, 190);
            this.grpActions.Size = new System.Drawing.Size(860, 70);
            this.Controls.Add(this.grpActions);

            this.btnThem.Text = "Thêm";
            this.btnThem.Location = new System.Drawing.Point(20, 25);
            this.btnThem.Size = new System.Drawing.Size(100, 32);
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            this.grpActions.Controls.Add(this.btnThem);

            this.btnSua.Text = "Sửa";
            this.btnSua.Location = new System.Drawing.Point(160, 25);
            this.btnSua.Size = new System.Drawing.Size(100, 32);
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            this.grpActions.Controls.Add(this.btnSua);

            this.btnXoa.Text = "Xóa";
            this.btnXoa.Location = new System.Drawing.Point(300, 25);
            this.btnXoa.Size = new System.Drawing.Size(100, 32);
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            this.grpActions.Controls.Add(this.btnXoa);

            this.btnThoat.Text = "Thoát";
            this.btnThoat.Location = new System.Drawing.Point(740, 25);
            this.btnThoat.Size = new System.Drawing.Size(100, 32);
            this.btnThoat.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            this.grpActions.Controls.Add(this.btnThoat);

            this.grpList.Text = "Thông tin chung sinh viên:";
            this.grpList.Location = new System.Drawing.Point(20, 265);
            this.grpList.Size = new System.Drawing.Size(860, 300);
            this.Controls.Add(this.grpList);

            this.lvSinhVien.Location = new System.Drawing.Point(15, 25);
            this.lvSinhVien.Size = new System.Drawing.Size(830, 260);
            this.lvSinhVien.View = System.Windows.Forms.View.Details;
            this.lvSinhVien.FullRowSelect = true;
            this.lvSinhVien.GridLines = true;
            this.lvSinhVien.MultiSelect = false;
            this.lvSinhVien.HideSelection = false;
            this.lvSinhVien.SelectedIndexChanged += new System.EventHandler(this.lvSinhVien_SelectedIndexChanged);

            this.colHoTen.Text = "Họ tên"; this.colHoTen.Width = 220;
            this.colNgaySinh.Text = "Ngày sinh"; this.colNgaySinh.Width = 120;
            this.colLop.Text = "Lớp"; this.colLop.Width = 100;
            this.colDiaChi.Text = "Địa chỉ"; this.colDiaChi.Width = 360;

            this.lvSinhVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                this.colHoTen, this.colNgaySinh, this.colLop, this.colDiaChi
            });

            this.grpList.Controls.Add(this.lvSinhVien);
        }
        #endregion
    }
}
