﻿using System;
using System.Globalization;
using System.Windows.Forms;

namespace ChiHan_1150080014_BTTuan6_TH2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dtpNgaySinh.Value = DateTime.Today;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên không được rỗng.", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            var item = new ListViewItem(txtHoTen.Text.Trim());
            item.SubItems.Add(dtpNgaySinh.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
            item.SubItems.Add(txtLop.Text.Trim());
            item.SubItems.Add(txtDiaChi.Text.Trim());

            lvSinhVien.Items.Add(item);
            ClearInputs();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Hãy chọn 1 dòng để sửa.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên không được rỗng.", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            var sel = lvSinhVien.SelectedItems[0];
            sel.Text = txtHoTen.Text.Trim();
            sel.SubItems[1].Text = dtpNgaySinh.Value.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            sel.SubItems[2].Text = txtLop.Text.Trim();
            sel.SubItems[3].Text = txtDiaChi.Text.Trim();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Hãy chọn 1 dòng để xóa.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            lvSinhVien.Items.Remove(lvSinhVien.SelectedItems[0]);
            ClearInputs();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            var sel = lvSinhVien.SelectedItems[0];

            txtHoTen.Text = sel.Text;

            DateTime d;
            if (DateTime.TryParse(sel.SubItems[1].Text, out d))
                dtpNgaySinh.Value = d;
            else
                dtpNgaySinh.Value = DateTime.Today;

            txtLop.Text = sel.SubItems[2].Text;
            txtDiaChi.Text = sel.SubItems[3].Text;
        }

        private void ClearInputs()
        {
            txtHoTen.Clear();
            txtLop.Clear();
            txtDiaChi.Clear();
            dtpNgaySinh.Value = DateTime.Today;
            txtHoTen.Focus();
        }
    }
}
