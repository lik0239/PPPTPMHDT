﻿namespace ChiHan_1150080014_BTTuan6
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Panel bannerPanel;
        private System.Windows.Forms.Label lblTitle;

        private System.Windows.Forms.Label lblDanhSach;
        private System.Windows.Forms.TableLayoutPanel tlpMenu;

        private System.Windows.Forms.Panel stripPanel;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label lblChonBan;
        private System.Windows.Forms.ComboBox cboTable;
        private System.Windows.Forms.Button btnOrder;

        private System.Windows.Forms.DataGridView dgv;

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn15;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.headerPanel = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.bannerPanel = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblDanhSach = new System.Windows.Forms.Label();
            this.tlpMenu = new System.Windows.Forms.TableLayoutPanel();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.stripPanel = new System.Windows.Forms.Panel();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lblChonBan = new System.Windows.Forms.Label();
            this.cboTable = new System.Windows.Forms.ComboBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.headerPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.bannerPanel.SuspendLayout();
            this.tlpMenu.SuspendLayout();
            this.stripPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            this.headerPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.headerPanel.BackColor = System.Drawing.Color.White;
            this.headerPanel.Controls.Add(this.picLogo);
            this.headerPanel.Controls.Add(this.bannerPanel);
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(900, 70);
            this.headerPanel.TabIndex = 0;

            this.picLogo.Image = global::ChiHan_1150080014_BTTuan6.Properties.Resources.Hamberger;
            this.picLogo.Location = new System.Drawing.Point(8, 8);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(70, 54);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 0;
            this.picLogo.TabStop = false;
            this.picLogo.Click += new System.EventHandler(this.picLogo_Click);

            this.bannerPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bannerPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.bannerPanel.Controls.Add(this.lblTitle);
            this.bannerPanel.Location = new System.Drawing.Point(90, 8);
            this.bannerPanel.Name = "bannerPanel";
            this.bannerPanel.Size = new System.Drawing.Size(800, 54);
            this.bannerPanel.TabIndex = 1;
 
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.lblTitle.Size = new System.Drawing.Size(800, 54);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Quán ăn nhanh Hưng Thịnh";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            this.lblDanhSach.AutoSize = true;
            this.lblDanhSach.Location = new System.Drawing.Point(10, 75);
            this.lblDanhSach.Name = "lblDanhSach";
            this.lblDanhSach.Size = new System.Drawing.Size(121, 16);
            this.lblDanhSach.TabIndex = 1;
            this.lblDanhSach.Text = "Danh sách món ăn:";

            this.tlpMenu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpMenu.ColumnCount = 4;
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.Controls.Add(this.btn1, 0, 0);
            this.tlpMenu.Controls.Add(this.btn2, 1, 0);
            this.tlpMenu.Controls.Add(this.btn3, 2, 0);
            this.tlpMenu.Controls.Add(this.btn4, 3, 0);
            this.tlpMenu.Controls.Add(this.btn5, 0, 1);
            this.tlpMenu.Controls.Add(this.btn6, 1, 1);
            this.tlpMenu.Controls.Add(this.btn7, 2, 1);
            this.tlpMenu.Controls.Add(this.btn8, 3, 1);
            this.tlpMenu.Controls.Add(this.btn9, 0, 2);
            this.tlpMenu.Controls.Add(this.btn10, 1, 2);
            this.tlpMenu.Controls.Add(this.btn11, 2, 2);
            this.tlpMenu.Controls.Add(this.btn12, 3, 2);
            this.tlpMenu.Controls.Add(this.btn13, 0, 3);
            this.tlpMenu.Controls.Add(this.btn14, 1, 3);
            this.tlpMenu.Controls.Add(this.btn15, 2, 3);
            this.tlpMenu.Location = new System.Drawing.Point(10, 95);
            this.tlpMenu.Name = "tlpMenu";
            this.tlpMenu.RowCount = 4;
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpMenu.Size = new System.Drawing.Size(880, 160);
            this.tlpMenu.TabIndex = 2;

            this.btn1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn1.Location = new System.Drawing.Point(8, 8);
            this.btn1.Margin = new System.Windows.Forms.Padding(8);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(204, 24);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "Cơm chiên trứng";
            this.btn1.Click += new System.EventHandler(this.menuButton_Click);

            this.btn2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn2.Location = new System.Drawing.Point(228, 8);
            this.btn2.Margin = new System.Windows.Forms.Padding(8);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(204, 24);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "Bánh mì ốp la";
            this.btn2.Click += new System.EventHandler(this.menuButton_Click);

            this.btn3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn3.Location = new System.Drawing.Point(448, 8);
            this.btn3.Margin = new System.Windows.Forms.Padding(8);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(204, 24);
            this.btn3.TabIndex = 2;
            this.btn3.Text = "Coca";
            this.btn3.Click += new System.EventHandler(this.menuButton_Click);

            this.btn4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn4.Location = new System.Drawing.Point(668, 8);
            this.btn4.Margin = new System.Windows.Forms.Padding(8);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(204, 24);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "Lipton";
            this.btn4.Click += new System.EventHandler(this.menuButton_Click);

            this.btn5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn5.Location = new System.Drawing.Point(8, 48);
            this.btn5.Margin = new System.Windows.Forms.Padding(8);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(204, 24);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "Ốc rang muối";
            this.btn5.Click += new System.EventHandler(this.menuButton_Click);

            this.btn6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn6.Location = new System.Drawing.Point(228, 48);
            this.btn6.Margin = new System.Windows.Forms.Padding(8);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(204, 24);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "Khoai tây chiên";
            this.btn6.Click += new System.EventHandler(this.menuButton_Click);

            this.btn7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn7.Location = new System.Drawing.Point(448, 48);
            this.btn7.Margin = new System.Windows.Forms.Padding(8);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(204, 24);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7 up";
            this.btn7.Click += new System.EventHandler(this.menuButton_Click);

            this.btn8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn8.Location = new System.Drawing.Point(668, 48);
            this.btn8.Margin = new System.Windows.Forms.Padding(8);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(204, 24);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "Cam";
            this.btn8.Click += new System.EventHandler(this.menuButton_Click);

            this.btn9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn9.Location = new System.Drawing.Point(8, 88);
            this.btn9.Margin = new System.Windows.Forms.Padding(8);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(204, 24);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "Mỳ xào hải sản";
            this.btn9.Click += new System.EventHandler(this.menuButton_Click);

            this.btn10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn10.Location = new System.Drawing.Point(228, 88);
            this.btn10.Margin = new System.Windows.Forms.Padding(8);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(204, 24);
            this.btn10.TabIndex = 9;
            this.btn10.Text = "Cá viên chiên";
            this.btn10.Click += new System.EventHandler(this.menuButton_Click);

            this.btn11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn11.Location = new System.Drawing.Point(448, 88);
            this.btn11.Margin = new System.Windows.Forms.Padding(8);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(204, 24);
            this.btn11.TabIndex = 10;
            this.btn11.Text = "Pepsi";
            this.btn11.Click += new System.EventHandler(this.menuButton_Click);

            this.btn12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn12.Location = new System.Drawing.Point(668, 88);
            this.btn12.Margin = new System.Windows.Forms.Padding(8);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(204, 24);
            this.btn12.TabIndex = 11;
            this.btn12.Text = "Cafe";
            this.btn12.Click += new System.EventHandler(this.menuButton_Click);
 
            this.btn13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn13.Location = new System.Drawing.Point(8, 128);
            this.btn13.Margin = new System.Windows.Forms.Padding(8);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(204, 24);
            this.btn13.TabIndex = 12;
            this.btn13.Text = "Buger bò nướng";
            this.btn13.Click += new System.EventHandler(this.menuButton_Click);

            this.btn14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn14.Location = new System.Drawing.Point(228, 128);
            this.btn14.Margin = new System.Windows.Forms.Padding(8);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(204, 24);
            this.btn14.TabIndex = 13;
            this.btn14.Text = "Đùi gà rán";
            this.btn14.Click += new System.EventHandler(this.menuButton_Click);

            this.btn15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn15.Location = new System.Drawing.Point(448, 128);
            this.btn15.Margin = new System.Windows.Forms.Padding(8);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(204, 24);
            this.btn15.TabIndex = 14;
            this.btn15.Text = "Bún bò Huế";
            this.btn15.Click += new System.EventHandler(this.menuButton_Click);

            this.stripPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stripPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stripPanel.Controls.Add(this.btnRemove);
            this.stripPanel.Controls.Add(this.lblChonBan);
            this.stripPanel.Controls.Add(this.cboTable);
            this.stripPanel.Controls.Add(this.btnOrder);
            this.stripPanel.Location = new System.Drawing.Point(10, 260);
            this.stripPanel.Name = "stripPanel";
            this.stripPanel.Size = new System.Drawing.Size(880, 52);
            this.stripPanel.TabIndex = 3;

            this.btnRemove.Location = new System.Drawing.Point(10, 9);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(100, 32);
            this.btnRemove.TabIndex = 0;
            this.btnRemove.Text = "Xóa";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);

            this.lblChonBan.AutoSize = true;
            this.lblChonBan.Location = new System.Drawing.Point(130, 16);
            this.lblChonBan.Name = "lblChonBan";
            this.lblChonBan.Size = new System.Drawing.Size(67, 16);
            this.lblChonBan.TabIndex = 1;
            this.lblChonBan.Text = "Chọn bàn:";

            this.cboTable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTable.Location = new System.Drawing.Point(200, 12);
            this.cboTable.Name = "cboTable";
            this.cboTable.Size = new System.Drawing.Size(160, 24);
            this.cboTable.TabIndex = 2;

            this.btnOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOrder.Location = new System.Drawing.Point(740, 9);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(120, 32);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "Order";
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);

            this.dgv.AllowUserToAddRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dgv.ColumnHeadersHeight = 29;
            this.dgv.Location = new System.Drawing.Point(10, 318);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(880, 320);
            this.dgv.TabIndex = 4;
 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 650);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.tlpMenu);
            this.Controls.Add(this.stripPanel);
            this.Controls.Add(this.dgv);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.headerPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.bannerPanel.ResumeLayout(false);
            this.tlpMenu.ResumeLayout(false);
            this.stripPanel.ResumeLayout(false);
            this.stripPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
}
