﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;

namespace ChiHan_1150080014_BTTuan6
{
    public partial class Form1 : Form
    {
        private DataTable orderTable;

        private readonly Dictionary<string, decimal> priceList = new Dictionary<string, decimal>
        {
            ["Cơm chiên trứng"] = 35000m,
            ["Bánh mì ốp la"] = 25000m,
            ["Coca"] = 15000m,
            ["Lipton"] = 12000m,
            ["Ốc rang muối"] = 60000m,
            ["Khoai tây chiên"] = 25000m,
            ["7 up"] = 15000m,
            ["Cam"] = 12000m,
            ["Mỳ xào hải sản"] = 55000m,
            ["Cá viên chiên"] = 20000m,
            ["Pepsi"] = 15000m,
            ["Cafe"] = 18000m,
            ["Buger bò nướng"] = 45000m,
            ["Đùi gà rán"] = 40000m,
            ["Bún bò Huế"] = 48000m
        };

        public Form1()
        {
            InitializeComponent();

            for (int i = 1; i <= 20; i++) cboTable.Items.Add("Bàn " + i);
            cboTable.SelectedIndex = 0;

            orderTable = new DataTable();
            orderTable.Columns.Add("Món", typeof(string));
            orderTable.Columns.Add("SL", typeof(int));
            orderTable.Columns.Add("Đơn giá", typeof(decimal));
            orderTable.Columns.Add("Thành tiền", typeof(decimal), "SL * [Đơn giá]");
            dgv.DataSource = orderTable;

            dgv.Columns["Món"].Width = 300;
            dgv.Columns["SL"].Width = 60;
            dgv.Columns["Đơn giá"].DefaultCellStyle.Format = "#,0₫";
            dgv.Columns["Thành tiền"].DefaultCellStyle.Format = "#,0₫";

            dgv.CellEndEdit += (s, e) =>
            {
                if (dgv.Columns[e.ColumnIndex].Name == "SL")
                {
                    int sl;
                    if (!int.TryParse(Convert.ToString(dgv.Rows[e.RowIndex].Cells["SL"].Value), out sl) || sl <= 0)
                    {
                        if (!dgv.Rows[e.RowIndex].IsNewRow) dgv.Rows.RemoveAt(e.RowIndex);
                    }
                    orderTable.AcceptChanges();
                }
            };
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            var b = sender as Button;
            if (b == null) return;
            string name = b.Text;

            if (!priceList.ContainsKey(name))
            {
                MessageBox.Show("Chưa có giá cho món: " + name);
                return;
            }

            var rows = orderTable.AsEnumerable().Where(r => r.Field<string>("Món") == name);
            if (rows.Any())
                rows.First()["SL"] = rows.First().Field<int>("SL") + 1;
            else
                orderTable.Rows.Add(name, 1, priceList[name]);

            orderTable.AcceptChanges();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn 1 dòng để xóa.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            foreach (DataGridViewRow row in dgv.SelectedRows)
                if (!row.IsNewRow) dgv.Rows.Remove(row);
            orderTable.AcceptChanges();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            if (orderTable.Rows.Count == 0)
            {
                MessageBox.Show("Chưa có món nào để Order.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string tableName = cboTable.SelectedItem != null ? cboTable.SelectedItem.ToString() : "Bàn ?";
            decimal total = orderTable.AsEnumerable().Sum(r => r.Field<int>("SL") * r.Field<decimal>("Đơn giá"));

            var lines = new List<string>();
            lines.Add("BÀN: " + tableName);
            lines.Add("THỜI GIAN: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            lines.Add(new string('-', 40));

            foreach (DataRow r in orderTable.Rows)
            {
                string n = r.Field<string>("Món");
                int q = r.Field<int>("SL");
                decimal p = r.Field<decimal>("Đơn giá");
                lines.Add(string.Format("{0} x {1}  @ {2:#,0}₫  = {3:#,0}₫", n, q, p, q * p));
            }
            lines.Add(new string('-', 40));
            lines.Add(string.Format("TỔNG: {0:#,0}₫", total));

            string outDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Orders");
            Directory.CreateDirectory(outDir);
            string fileName = string.Format("Order_{0}_{1}.txt", tableName.Replace(' ', '_'), DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            File.WriteAllLines(Path.Combine(outDir, fileName), lines.ToArray());

            MessageBox.Show("Đã ghi Order vào thư mục Documents/Orders.", "Thành công",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void picLogo_Click(object sender, EventArgs e)
        {

        }
    }
}
